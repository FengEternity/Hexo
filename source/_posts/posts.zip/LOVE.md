---
title: LOVE
date: 2025/3/31
tags:
  - love
categories: [日常杂谈]
cover: https://blog-imges-1313931661.cos.ap-nanjing.myqcloud.com/9741743264645_.pic_hd.jpg
mathjax: true
author: Montee
---
{% timeline %}
<!-- node 2025 年 4 月 11 日 -->
每次她来101学习，过程总是类似的：玩一会儿、没看几分钟开始困了、缠我，直到这里心情都还是不错的，然后我受不了指责她，她被我说得学一小会儿、开始烦躁、哪哪都不顺眼……

其实，每个人都有自己喜欢做的事，也有自己的人生，做什么都会很精彩，而不是强迫自己做不喜欢的事。现在想想，真的不要去过份思索未来，只会让自己焦虑不安。

<!-- node 2025 年 4 月 10 日 -->
值得被记录
![image.png](https://blog-image-0407-1313931661.cos.ap-nanjing.myqcloud.com/20250410230328741.png?imageSlim)

<!-- node 2025 年 4 月 9 日 -->
试验了宝宝买的素颜霜
![image.png](https://blog-image-0407-1313931661.cos.ap-nanjing.myqcloud.com/20250409004304846.png?imageSlim)

{% endtimeline %}
