---
title: 《C程序设计语言》—— 学习记录
date: 2025-04-9
tags:
  - C语言
  - 编程学习
cover: https://blog-image-0407-1313931661.cos.ap-nanjing.myqcloud.com/O1CN01ipxyGT1jCXoBnsQz3_!!6000000004512-2-yinhe.png?imageSlim
categories:
  - 技术学习
description: 
author: Forsertee
type: tech
topic: cpl
---

在开始之前还是应该先介绍一下我的个人学习状况，我并不是一个初学者，而是即将入职的一名毕业生。在此前也已经学习过C语言，因此在阅读这本书时可能会比较快速，同时不会有较为详细的笔记。

> 电子资源 : [C程序设计语言(K&R)清晰中文版.pdf](https://github.com/huyubing/books-pdf/blob/master/C程序设计语言(K%26R)清晰中文版.pdf)

{% timeline %}

<!-- node 2025 年 4 月 9 日 -->
开始阅读，希望能在一周看完！

{% endtimeline %}